////////////////////////////////////////////////////////////////////////////
//
/* write a program to check whether given year is leap year or not */
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
// Author : Nikhil Shankar Suryavanshi
//
/////////////////////////////////////////////////////////////////////////////

class Logic
{
    public void checkLeapYear(int year)
    {
        if((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
        {
            System.out.println(year + " is a leap year.");
        }
        else
        {
            System.out.println(year + " is not a leap year.");
        }
    }
}
class Question1
{
    public static void main(String arg[])
    {
        Logic obj = new Logic();
        obj.checkLeapYear(2024);
    }
}