////////////////////////////////////////////////////////////////////////////
//
/* write a program to calculate power of a number */
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
// Author : Nikhil Shankar Suryavanshi
//
/////////////////////////////////////////////////////////////////////////////

class Logic
{
    void calculatePower(int base, int exponent)
    {
        int result = 1;
        for(int i = 1; i <= exponent; i++)
        {
            result = result * base;
        }
        System.out.println(base + " raised to the power " + exponent + " is: " + result);
    }
}

class Question5 
{
    public static void main(String arg[])
    {
        Logic obj = new Logic();
        obj.calculatePower(2, 5);
    }
    
}
