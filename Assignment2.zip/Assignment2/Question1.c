// Display Stars Based on User Input with updator in while loop
    
#include<stdio.h>

void Display(int iNo)
{
    int iCnt = 0;
    if(iNo < 0)
    {
        iNo = -iNo;
    }
    while (iCnt < iNo)
    {
        printf("*");
        iCnt++;
    }
    
}

int main()
{
    int iValue = 0;

    printf("Enter number of asterisks to display:\n");
    scanf("%d", &iValue);

    Display(iValue);

    return 0;
}