// Check Whether Number is Even or Odd

#include <stdio.h>  
int ChkEvenOdd(int iNo)
{
    if(iNo % 2 == 0)
    {
        return 1; // Even
    }
    else
    {
        return 0; // Odd
    }
}

int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter a number:\n");
    scanf("%d", &iValue);

    iRet = ChkEvenOdd(iValue);

    if(iRet == 1)
    {
        printf("%d is Even\n", iValue);
    }
    else
    {
        printf("%d is Odd\n", iValue);
    }

    return 0;
}