////////////////////////////////////////////////////////////////////////////
//
/* write a program to calculate sum of even numbers */
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
// Author : Nikhil Shankar Suryavanshi
//
/////////////////////////////////////////////////////////////////////////////

class Logic
{
    void sumEvenNumber(int num)
    {
        int iSum = 0;

        for(int iCnt = 1; iCnt <= num; iCnt++)
        {
            if(iCnt % 2 == 0)
            {
                iSum = iSum + iCnt;
            }
        }
        System.out.println("Sum of even numbers till " + num + " is: " + iSum);
    }
}

class Question1 
{
    public static void main(String arg[])
    {
        Logic obj = new Logic();
        obj.sumEvenNumber(10);
    }
    
}
