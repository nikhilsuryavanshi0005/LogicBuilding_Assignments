////////////////////////////////////////////////////////////////////////////
//
/* write a program to check the number is perfect number or not */
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
// Author : Nikhil Shankar Suryavanshi
//
/////////////////////////////////////////////////////////////////////////////

class Logic
{
    void checkPerfectNumber(int num)
    {
        int iSum = 0;
        for(int iCnt = 1; iCnt <= num / 2; iCnt++)
        {
            if(num % iCnt == 0)
            {
                iSum = iSum + iCnt;
            }
        }
        if(iSum == num)
        {
            System.out.println(num + " is a perfect number.");
        }
        else
        {
            System.out.println(num + " is not a perfect number.");
        }
    }
}
class Question3 
{
    public static void main(String arg[])
    {
        Logic obj = new Logic();
        obj.checkPerfectNumber(6);
    }
    
}
