////////////////////////////////////////////////////////////////////////////
//
/* write a program to find largest number in a given number */
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
// Author : Nikhil Shankar Suryavanshi
//
/////////////////////////////////////////////////////////////////////////////

class Logic
{
    void findLargestDigit(int num)
    {
        int largest = 0;
        while(num != 0)
        {
            int digit = num % 10;
            if(digit > largest)
            {
                largest = digit;
            }
            num = num / 10;
        }
        System.out.println("Largest digit is: " + largest);
    }
    
}
class Question4 
{
    public static void main(String arg[])
    {
        Logic obj = new Logic();
        obj.findLargestDigit(83429);
    }
    
}
