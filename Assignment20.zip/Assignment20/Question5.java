////////////////////////////////////////////////////////////////////////////
//
/* write a program to find smallest number in a given number */
//
/////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////
//
// Author : Nikhil Shankar Suryavanshi
//
/////////////////////////////////////////////////////////////////////////////

class Logic
{
    void findSmallestDigit(int num)
    {
        int smallest = 9;
        while(num != 0)
        {
            int digit = num % 10;
            if(digit < smallest)
            {
                smallest = digit;
            }
            num = num / 10;
        }
        System.out.println("Smallest digit is: " + smallest);
    }
    
}
class Question5 
{
    public static void main(String arg[])
    {
        Logic obj = new Logic();
        obj.findSmallestDigit(45872);
    }
    
}

