//Accept Number from user and Display below pattern
//Input : 5
//Output : A B C D E

#include<stdio.h>
void Pattern(int iNo)
{
    char ch = 'A';  // Use single quotes for character literals

    int i =0;

    for(i=1;i<=iNo;i++)
    {
        printf("%c\t",ch);
        ch++;
    }
    printf("\n");
}
int main()
{
    int iValue = 0;

    printf("Enter the Number :\n");
    scanf("%d",&iValue);

    Pattern(iValue);

    return 0;
}