//Accept number from user and display below pattern.
//input : 8
//output : 2    4   6   8   10  12  14  16

#include<stdio.h>

void Pattern(int iNo)
{
    int iCnt = 0;
    for(iCnt = 2; iCnt <= iNo;iCnt+2)
    {
        printf("%d",iCnt);
    }
}


int main()
{
    int iValue = 0;
    
    printf("Enter the Number :\n");
    scanf("%d",&iValue);

    Pattern(iValue);

    return 0;
}