/*
Accept Number of rows and number of columns from the user and diplay below pattern.

input : iRow = 4 iCol = 4

    output : A   B   C   D
             a   b   c   d
             A   B   C   D
             a   b   c   d
*/

#include<stdio.h>
void Pattern(int iRow,int iCol)
{
    int i =0;
    int j =0;
    

    for(i=1;i<=iRow;i++)
    {
        char ch = 'A';
        char dh = 'a';

        for(j=1;j<=iCol;j++)
        {
            if(i%2==0)
            {
                printf("%c\t",dh);
                dh++;

            }
            else
            {
                printf("%c\t",ch);
                ch++;

            }
        }
        printf("\n");
    }
}
int main()
{
    int iValue1 =0;
    int iValue2 =0;

    printf("Enter the Number of Rows :\n");
    scanf("%d",&iValue1);

    printf("Enter the Number of Columns :\n");
    scanf("%d",&iValue2);

    Pattern(iValue1,iValue2);
}