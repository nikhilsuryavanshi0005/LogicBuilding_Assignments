/*
Accept Number of rows and number of columns from the user and diplay below pattern.

input : iRow = 4 iCol = 5

    output : 2   4   6   8  10
             1   3   5   7   9
             2   4   6   8  10
             1   3   5   7   9            
*/

#include<stdio.h>
void Pattern(int iRow,int iCol)
{
    int i =0;
    int j =0;
    
    for(i=1;i<=iRow;i++)
    {
       
        int num = 1;
        for(j=1;j<=iCol;j++,num++)
        {
            if((i%2)==0)
            {
                printf("%d\t",j);    
            }
            else
            {
                printf("%d\t",num*2);
                       
            }
                      
        }
        printf("\n");
        
    }
}
int main()
{
    int iValue1 =0;
    int iValue2 =0;

    printf("Enter the Number of Rows :\n");
    scanf("%d",&iValue1);

    printf("Enter the Number of Columns :\n");
    scanf("%d",&iValue2);

    Pattern(iValue1,iValue2);
}