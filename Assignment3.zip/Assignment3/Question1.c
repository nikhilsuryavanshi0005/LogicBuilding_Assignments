// Display Even Numbers up to N

#include<stdio.h>

void PrintEven(int iNo)
{
    if(iNo <= 0)
    {
        return;
    }
    int i = 2;
    int iCnt = 0;

    while (iCnt < iNo)
    {
        printf("%d\t",i);
        i = i + 2;
        iCnt++;
    }
    

}
int main()
{
    int iValue = 0;

    printf("Enter Number\n");
    scanf("%d",&iValue);

    PrintEven(iValue);

    return 0;
}
