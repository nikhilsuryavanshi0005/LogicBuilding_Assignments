// Convert Uppercase character to Lowercase or Lowercase character to Uppercase
#include<stdio.h>

void DisplayConvert(char cValue)
{
    if(cValue >= 'a' && cValue <= 'z')
    {
        cValue = cValue - 32;
    }
    else if(cValue >= 'A' && cValue <= 'Z')
    {
        cValue = cValue + 32;
    }
    printf("Converted character is: %c\n",cValue);
}
int main()
{
    char cValue = '\0';

    printf("Enter Character\n");
    scanf("%c",&cValue);

    DisplayConvert(cValue);

    return 0;
}