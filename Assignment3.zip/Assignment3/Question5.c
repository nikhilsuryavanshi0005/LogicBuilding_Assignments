// Check Whether Character is Vowel or Not
#include<stdio.h>
typedef int vowel;
#define TRUE 1
#define FALSE 0
vowel CheckVowel(char cValue)
{
    if((cValue == 'a') || (cValue == 'e') || (cValue == 'i') || (cValue == 'o') || (cValue == 'u') ||
       (cValue == 'A') || (cValue == 'E') || (cValue == 'I') || (cValue == 'O') || (cValue == 'U'))
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

int main()
{
    char cValue = '\0';
    vowel bRet = FALSE;

    printf("Enter Character\n");
    scanf("%c",&cValue);

    bRet = CheckVowel(cValue);

    if(bRet == TRUE)
    {
        printf("%c is Vowel\n",cValue);
    }
    else
    {
        printf("%c is not Vowel\n",cValue);
    }

    return 0;
}
