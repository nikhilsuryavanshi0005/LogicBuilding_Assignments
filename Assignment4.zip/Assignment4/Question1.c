// Write a program which will accept number from user and display its multiplication of factors.

#include<stdio.h>

int MultiFact(int iNo)
{
    int i = 0;
    int Mult = 1;

    if(iNo < 0)
    {
        iNo = -iNo;
    }

    for(i =1; i <= iNo/2; i++)
    {
        if((iNo % i) == 0)
        {
            Mult = Mult * i;
        }
    }
    return Mult;
       
}   
int main()
{
    int iValue = 0;
    int iRet = 0;

    printf("Enter Number\n");
    scanf("%d",&iValue);

    iRet = MultiFact(iValue);

    printf("Multiplication of Factors is : %d\n",iRet);

    return 0;
}

    