//Check whether the given number is even or odd

#include<stdio.h>

void CheckEvenOdd(int num)
{
    if(num%2==0)
    {
        printf("%d is Even Number\n",num);
    }
    else
    {
        printf("%d is Odd Number\n",num);
    }
}
int main()
{
int iNumber =0;

printf("Enter the Number :\n");
scanf("%d",&iNumber);

CheckEvenOdd(iNumber);

return 0;

}