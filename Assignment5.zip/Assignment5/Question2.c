//Find Maximum of Two Numbers

#include<stdio.h>

int FindMax(int iNum1, int iNum2)
{
    if(iNum1 > iNum2)
    {
        return iNum1;
    }
    else
    {
        return iNum2;
    }
    
}

int mian()
{
    int iValue1 = 0;
    int iValue2 = 0;
    int iRet = 0;

    printf("Enter the First Number :\n");
    scanf("%d",&iValue1);

    printf("Enter the Second Number :\n");
    scanf("%d",&iValue2);

    iRet = FindMax(iValue1,iValue2);

    printf("Maximum Number is :%d\n",iRet);

    return 0;
}