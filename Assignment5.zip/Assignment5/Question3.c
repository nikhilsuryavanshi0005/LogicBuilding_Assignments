//Check Leap Year

#include<stdio.h>

void CheckLeaf(int iYear)
{
    if(iYear % 4 == 0)
    {
        printf("%d is a Leap Year\n",iYear);
    }
    else
    {
        printf("%d is not a Leap Year\n",iYear);
    }
}

int main()
{
    int iValue = 0;
    

    printf("Enter the Year :\n");
    scanf("%d",&iValue);

    CheckLeaf(iValue);

    
    return 0;
}