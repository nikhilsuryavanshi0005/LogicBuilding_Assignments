//Check the Nummber is Positive,Negative or Zero

#include<stdio.h>

void CheckNumberType(int iNumber)
{
    if(iNumber >0)
    {
        printf("%d is Positive Number\n",iNumber);
    }
    else if(iNumber <0)
    {
        printf("%d is Negative Number\n",iNumber);
    }
    else
    {
        printf(" %d The number is Zero\n",iNumber);
    }
}

int main()
{
    int iValue = 0;
    

    printf("Enter the Number :\n");
    scanf("%d",&iValue);

    CheckNumberType(iValue);

    
    return 0;
}